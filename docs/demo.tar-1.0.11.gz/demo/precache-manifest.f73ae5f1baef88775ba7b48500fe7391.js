self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b729990b53ac534c8f0e",
    "url": "css/app.c91b9596.css"
  },
  {
    "revision": "2ee968735195566e7de5",
    "url": "css/chunk-vendors.f5af2542.css"
  },
  {
    "revision": "6cf071566d73aa60edfe8a323164736d",
    "url": "fonts/mary.6cf07156.ttf"
  },
  {
    "revision": "959abe93dc6906bdb5014185fcb79c5a",
    "url": "img/@letter-i.959abe93.svg"
  },
  {
    "revision": "799be2096163c800f2ebebe184fd984c",
    "url": "img/address-book.799be209.svg"
  },
  {
    "revision": "1c753400e3a21113667f4ec552db0740",
    "url": "img/arrow-narrow-down.1c753400.svg"
  },
  {
    "revision": "12e3bebba1c6993dc46d25af807c5cba",
    "url": "img/arrow-narrow-left.12e3bebb.svg"
  },
  {
    "revision": "e4ad386e017d06efb82537db5c35f4b0",
    "url": "img/arrow-narrow-right.e4ad386e.svg"
  },
  {
    "revision": "2b6fb54a4a23fc327d8a055c762652e5",
    "url": "img/arrow-narrow-top.2b6fb54a.svg"
  },
  {
    "revision": "be34375eaa468cc43050683f60b573ac",
    "url": "img/arrows-shuffle.be34375e.svg"
  },
  {
    "revision": "b0163f202c484c518e2cd58cf31c801b",
    "url": "img/atom.b0163f20.svg"
  },
  {
    "revision": "b987588e25829d23d855cfc526089c94",
    "url": "img/barcode.b987588e.svg"
  },
  {
    "revision": "13df5165014ab59dbe57e40f3551b23f",
    "url": "img/brand-css3.13df5165.svg"
  },
  {
    "revision": "bf174965c11c14151e39d693ef5e529b",
    "url": "img/brand-discord.bf174965.svg"
  },
  {
    "revision": "1290e345c3abe458eb913e9a734a1b9d",
    "url": "img/calendar.1290e345.svg"
  },
  {
    "revision": "de4b5d115177ffce5e0e7a8477bad631",
    "url": "img/columns.de4b5d11.svg"
  },
  {
    "revision": "49e2f3d0cd44a79ce29dc955ac89883e",
    "url": "img/command.49e2f3d0.svg"
  },
  {
    "revision": "5832c391c20e88ac5b3f26ce63ee149c",
    "url": "img/file.5832c391.svg"
  },
  {
    "revision": "cc2e952c904dc7486e64dbeb54a372de",
    "url": "img/filter.cc2e952c.svg"
  },
  {
    "revision": "c61cc6360d7f465c2eff9730a3dd3e3a",
    "url": "img/first-brain.c61cc636.png"
  },
  {
    "revision": "c021a4f43db2e8e58850bdc1a9400efa",
    "url": "img/folder-plus.c021a4f4.svg"
  },
  {
    "revision": "60d77374a754a569f56697d894f9a022",
    "url": "img/folders.60d77374.svg"
  },
  {
    "revision": "0201bc8aa6f40ff40badcac099d9d839",
    "url": "img/grid-dots.0201bc8a.svg"
  },
  {
    "revision": "f483223d798143f5a4c65c380bf491f3",
    "url": "img/hand-move.f483223d.svg"
  },
  {
    "revision": "d670ea8088b8cf7532c5d7022dd00bcb",
    "url": "img/hash.d670ea80.svg"
  },
  {
    "revision": "ff4f0b5fd55ee2a59de25cb4ce5d514f",
    "url": "img/keyboard.ff4f0b5f.svg"
  },
  {
    "revision": "1f8f7dbb2742a02fcc18120982c2ac0c",
    "url": "img/language.1f8f7dbb.svg"
  },
  {
    "revision": "d93d1a1953216df8df3b4051f0cba3ec",
    "url": "img/layout-grid.d93d1a19.svg"
  },
  {
    "revision": "6d58c29f2291e51cf33500af985a4c9e",
    "url": "img/letter-case.6d58c29f.svg"
  },
  {
    "revision": "de84712530ff6380bad10183b50abccc",
    "url": "img/letter-i.de847125.svg"
  },
  {
    "revision": "70bebf415655b4ae78f56692bd4fdec7",
    "url": "img/letter-t.70bebf41.svg"
  },
  {
    "revision": "3ed9d930aa8fd9374fcb25711e4ee527",
    "url": "img/lifebuoy.3ed9d930.svg"
  },
  {
    "revision": "e5891ca3b826c6952f8cf858fd357749",
    "url": "img/link.e5891ca3.svg"
  },
  {
    "revision": "814e23e142d6cdc26eec27266326e44d",
    "url": "img/list-details.814e23e1.svg"
  },
  {
    "revision": "86278690d3529445fc7b38845736b1bf",
    "url": "img/list.86278690.svg"
  },
  {
    "revision": "6684693ae2c39b4018f3577bc78d0746",
    "url": "img/live-view.6684693a.svg"
  },
  {
    "revision": "a89c7cc29247d0ed3d86a60098e3dc95",
    "url": "img/logo.a89c7cc2.svg"
  },
  {
    "revision": "de84712530ff6380bad10183b50abccc",
    "url": "img/logo.de847125.svg"
  },
  {
    "revision": "e663ed8700e976683a865ece0fe12758",
    "url": "img/lupe.e663ed87.svg"
  },
  {
    "revision": "1c7ee503d49241eff26e85a19448bfab",
    "url": "img/mail-forward.1c7ee503.svg"
  },
  {
    "revision": "43ec8e371bad4f88ae98bfc26e70d274",
    "url": "img/markdown.43ec8e37.svg"
  },
  {
    "revision": "92aebdd00c137c5b5cb3fe766cb3ceeb",
    "url": "img/math-function.92aebdd0.svg"
  },
  {
    "revision": "eb9ac5f84607d39df7f4da05759f1ea1",
    "url": "img/maximize.eb9ac5f8.svg"
  },
  {
    "revision": "6566a2524e9e1234919f6d35ef0909ee",
    "url": "img/menu.6566a252.svg"
  },
  {
    "revision": "1e67585f20fa020d00768237ca1403f5",
    "url": "img/minus.1e67585f.svg"
  },
  {
    "revision": "e4eddd2d1b0ed4991c13d78800ab3dd6",
    "url": "img/moon-stars.e4eddd2d.svg"
  },
  {
    "revision": "230cd0fb9614b9b10d0dafbd3305ea54",
    "url": "img/moon.230cd0fb.svg"
  },
  {
    "revision": "948fe3883e6384e87c916b1cee8e1b3d",
    "url": "img/network.948fe388.svg"
  },
  {
    "revision": "6758e4442bfc87d82746a67a0ccdb472",
    "url": "img/news.6758e444.svg"
  },
  {
    "revision": "a89c7cc29247d0ed3d86a60098e3dc95",
    "url": "img/notebook.a89c7cc2.svg"
  },
  {
    "revision": "a89c7cc29247d0ed3d86a60098e3dc95",
    "url": "img/open-book.a89c7cc2.svg"
  },
  {
    "revision": "cfa25fd8f39af2b7edfeb7dc8aa21351",
    "url": "img/outline.cfa25fd8.svg"
  },
  {
    "revision": "5854eab529dbb3c35fdaa60198b59ee7",
    "url": "img/package.5854eab5.svg"
  },
  {
    "revision": "1cd3b5102cda3bab85e06538ab83d37f",
    "url": "img/palette.1cd3b510.svg"
  },
  {
    "revision": "f378268b7ba212a0fb080eccc32b36ed",
    "url": "img/paperclip.f378268b.svg"
  },
  {
    "revision": "a539ba565dfdf81d0b8849427a557d15",
    "url": "img/photo.a539ba56.svg"
  },
  {
    "revision": "97536c21a981e8f526810b2d79a053fd",
    "url": "img/planet.97536c21.svg"
  },
  {
    "revision": "428b96c15854ee93a44811dfdb7b7984",
    "url": "img/play.428b96c1.svg"
  },
  {
    "revision": "5ca58f258282cbdc343e2494a5f7d8b9",
    "url": "img/player-play.5ca58f25.svg"
  },
  {
    "revision": "a3ce42d6908b3542531005865ae95e4d",
    "url": "img/plugin.a3ce42d6.svg"
  },
  {
    "revision": "8ccf7db7cb8028b90afb9dda99027129",
    "url": "img/plus.8ccf7db7.svg"
  },
  {
    "revision": "74e49fa711a51d0791c78bdd680baa77",
    "url": "img/point.74e49fa7.svg"
  },
  {
    "revision": "7bab33fb699068a2b139d0e719244046",
    "url": "img/prompt.7bab33fb.svg"
  },
  {
    "revision": "12204fe208a80eca55bd4242255ae418",
    "url": "img/question-mark.12204fe2.svg"
  },
  {
    "revision": "0b8ec3f6a37e01891a6739d666453086",
    "url": "img/random.0b8ec3f6.svg"
  },
  {
    "revision": "636892aba09caed4629f0703895cbf34",
    "url": "img/report.636892ab.svg"
  },
  {
    "revision": "4736a320344c871162c129d3b9f124f9",
    "url": "img/save.4736a320.svg"
  },
  {
    "revision": "f45fa072ef4d656f075787174635bc9e",
    "url": "img/settings.f45fa072.svg"
  },
  {
    "revision": "bc429aece93ccc0c4ae8701b92035bd7",
    "url": "img/single-page.bc429aec.svg"
  },
  {
    "revision": "525236458c84131e03bb60e3a9d5edd1",
    "url": "img/sitemap.52523645.svg"
  },
  {
    "revision": "02b65d0547e7d736d8af84aa02d366f9",
    "url": "img/split-horizontal.02b65d05.svg"
  },
  {
    "revision": "9f33ba1cf18d42074e3f20047db459ba",
    "url": "img/split-vertical.9f33ba1c.svg"
  },
  {
    "revision": "2e7e321c6c2e826e8bd7914f480fd83a",
    "url": "img/star-off.2e7e321c.svg"
  },
  {
    "revision": "a95e48b9bcc7335d2f4dacc548daa193",
    "url": "img/star.a95e48b9.svg"
  },
  {
    "revision": "aeea4c23ed8cb320a53c85a8f112e22c",
    "url": "img/tag.aeea4c23.svg"
  },
  {
    "revision": "2f72163fdc7cee0c8a71b54c856212a7",
    "url": "img/tech-box.2f72163f.svg"
  },
  {
    "revision": "2aaff5be1cb700a48d76c054ab47e499",
    "url": "img/template.2aaff5be.svg"
  },
  {
    "revision": "03059f837361fc3b4b8ee3cb766900c8",
    "url": "img/terminal.03059f83.svg"
  },
  {
    "revision": "7e5656dc59978fa54fefc00adc164a28",
    "url": "img/tool.7e5656dc.svg"
  },
  {
    "revision": "53702ca8cd773560ba4afbe8d1e13013",
    "url": "img/tools.53702ca8.svg"
  },
  {
    "revision": "99d896ea9cc8e5025e7de1d12164e1c4",
    "url": "img/trash.99d896ea.svg"
  },
  {
    "revision": "638b561933485e42704959a79e89a81b",
    "url": "img/tree.638b5619.svg"
  },
  {
    "revision": "20e700ca50d715e649821f8fdfab65f6",
    "url": "img/typography.20e700ca.svg"
  },
  {
    "revision": "902b8d76683ee62684af6a94f0464e9e",
    "url": "img/users.902b8d76.svg"
  },
  {
    "revision": "2e55a8f326f2c7298271b9ad51783f1a",
    "url": "img/variable.2e55a8f3.svg"
  },
  {
    "revision": "0771d6de81f017522585d4e5e4ecc644",
    "url": "img/versions.0771d6de.svg"
  },
  {
    "revision": "3d618662a752b7d39b690aa64e99386c",
    "url": "img/vertical-list.3d618662.svg"
  },
  {
    "revision": "bf601f13bfc00956cc52f324d4b85ddb",
    "url": "img/video.bf601f13.svg"
  },
  {
    "revision": "424e1eeb639668ccb3ebaf2e29b6cda5",
    "url": "img/vocabulary.424e1eeb.svg"
  },
  {
    "revision": "ff929adb58fea49803ad838491fd366a",
    "url": "img/writing.ff929adb.svg"
  },
  {
    "revision": "1480f85125a3f136a7bd43715604b246",
    "url": "img/x.1480f851.svg"
  },
  {
    "revision": "df5160d971ec5f954c8727b20fadbc80",
    "url": "index.html"
  },
  {
    "revision": "b729990b53ac534c8f0e",
    "url": "js/app.2713dc78.js"
  },
  {
    "revision": "2ee968735195566e7de5",
    "url": "js/chunk-vendors.906bd451.js"
  },
  {
    "revision": "7a8bf79ecfc457b6122de5f42c01f1f3",
    "url": "manifest.json"
  }
]);